package com.example.a209877_nurainasafiah_drnazatul_project2

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun PreviewScreen(
    navController: NavController,
    viewModel: MainViewModel
) {
// Get current invitation data from ViewModel
    val data = viewModel.invitation.value

// SCREEN CONTAINER (overall background + layout wrapper)
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // HEADER
            Text(
                text = "Preview Dashboard",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(20.dp))

            // PROFILE CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {

                Column(modifier = Modifier.padding(16.dp)) {

                    Text(
                        text = "User Overview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        "👤 Name: ${data.name.ifBlank { "Not set yet" }}",
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        "⭐ XP: ${data.xp}",
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        "🔥 Streak: ${data.streak}",
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // STATUS CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {

                Column(modifier = Modifier.padding(16.dp)) {

                    Text(
                        text = "Performance Status",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val status = when {
                        data.name.isBlank() -> "⚠️ Please enter your name first"
                        data.xp < 100 -> "🌱 Beginner - Keep going!"
                        data.xp < 300 -> "🚀 Intermediate - Good progress!"
                        else -> "🔥 Advanced - Excellent work!"
                    }

                    Text(
                        status,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // BUTTONS
            Button(
                onClick = {
                    navController.navigate("details")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("View Details")
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = {
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Back")
            }
        }
    }
}