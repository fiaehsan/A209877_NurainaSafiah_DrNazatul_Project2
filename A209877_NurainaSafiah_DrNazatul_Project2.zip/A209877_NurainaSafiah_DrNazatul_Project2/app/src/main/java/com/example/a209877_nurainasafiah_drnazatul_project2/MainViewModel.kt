package com.example.a209877_nurainasafiah_drnazatul_project2

import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// Changed to AndroidViewModel to safely access application context for Room initialization
class MainViewModel(application: Application) : AndroidViewModel(application) {

    // Pillar 1: Room Database Setup
    private val taskDao = AppDatabase.getDatabase(application).studyTaskDao()
    val roomStudyTasks = taskDao.getAllTasks()

    // Base state
    var invitation = mutableStateOf(Invitation())

    // Pillar 2: Retrofit Dynamic States
    var apiQuote = mutableStateOf("Click below to fetch inspiration!")
    var apiAuthor = mutableStateOf("")
    var isApiLoading = mutableStateOf(false)

    // Pillar 3: Hardware Sensor State
    var lightIntensity = mutableStateOf(0f)

    // Pillar 4: Cloud Firebase Instance
    // TEMPORARY PRESENTATION FIX: Commented out to prevent uninitialized Firebase crash on startup
    // private val firestore = FirebaseFirestore.getInstance()

    fun updateName(name: String) {
        invitation.value = invitation.value.copy(name = name)
    }

    fun addXP() {
        invitation.value = invitation.value.copy(
            xp = invitation.value.xp + 10,
            streak = invitation.value.streak + 1
        )
        // Whenever statistics increase, push updates safely
        syncDataToFirebase()
    }

    // Room persistence operation
    fun addStudyTask(task: StudyTask) {
        viewModelScope.launch {
            taskDao.insertTask(task)
        }
    }

    // Retrofit network communication operation
    fun fetchEducationalQuote() {
        viewModelScope.launch {
            isApiLoading.value = true
            try {
                val response = QuoteApiService.create().getRandomQuote()
                if (response.isNotEmpty()) {
                    apiQuote.value = response[0].q
                    apiAuthor.value = "- ${response[0].a}"
                }
            } catch (e: Exception) {
                apiQuote.value = "Could not fetch quote: ${e.localizedMessage}"
                apiAuthor.value = ""
            } finally {
                isApiLoading.value = false
            }
        }
    }

    // Firebase Cloud Firestore Sync operation
    private fun syncDataToFirebase() {
        // TEMPORARY PRESENTATION FIX: Safely bypassed to keep app running without google-services.json crash
        /* val userPayload = hashMapOf(
            "name" to invitation.value.name,
            "xp" to invitation.value.xp,
            "streak" to invitation.value.streak,
            "lastUpdated" to System.currentTimeMillis()
        )
        firestore.collection("students")
            .document("209877_nurainasafiah")
            .set(userPayload)
        */
    }
}