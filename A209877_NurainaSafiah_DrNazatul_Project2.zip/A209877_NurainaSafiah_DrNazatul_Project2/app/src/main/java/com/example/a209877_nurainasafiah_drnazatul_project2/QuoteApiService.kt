package com.example.a209877_nurainasafiah_drnazatul_project2

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

data class QuoteResponse(
    val q: String,
    val a: String
)

interface QuoteApiService {

    @GET("api/random")
    suspend fun getRandomQuote(): List<QuoteResponse>

    companion object {
        private const val BASE_URL = "https://zenquotes.io/"

        fun create(): QuoteApiService {
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(QuoteApiService::class.java)
        }
    }
}