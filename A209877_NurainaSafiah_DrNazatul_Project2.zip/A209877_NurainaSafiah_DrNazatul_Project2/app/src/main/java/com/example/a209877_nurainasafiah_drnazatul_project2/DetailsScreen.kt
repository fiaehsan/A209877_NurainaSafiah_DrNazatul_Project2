package com.example.a209877_nurainasafiah_drnazatul_project2

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun DetailsScreen(
    navController: NavController,
    viewModel: MainViewModel
) {
    // Get current user data from ViewModel
    val data = viewModel.invitation.value
// Main screen container
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
// Vertical layout for arranging UI components
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // HEADER
            Text(
                text = "Details Overview",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(20.dp))

            // USER CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {

                Column(modifier = Modifier.padding(16.dp)) {

                    Text(
                        text = "User Summary",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))
// Display user name
                    Text(
                        "👤 Name: ${data.name.ifBlank { "Not set" }}",
                        color = MaterialTheme.colorScheme.onSurface
                    )
// Display XP value
                    Text(
                        "⭐ XP: ${data.xp}",
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    // Display streak value
                    Text(
                        "🔥 Streak: ${data.streak}",
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // INSIGHT CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {

                Column(modifier = Modifier.padding(16.dp)) {

                    Text(
                        text = "Performance Insight",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Determine user level based on XP
                    val level = when {
                        data.xp < 100 -> "🌱 Beginner"
                        data.xp < 300 -> "🚀 Intermediate"
                        else -> "🔥 Advanced"
                    }
// Display motivational message based on XP
                    val message = when {
                        data.xp < 100 -> "Keep building your consistency!"
                        data.xp < 300 -> "Great progress, keep it up!"
                        else -> "Excellent performance!"
                    }
// Show calculated level
                    Text(
                        "Level: $level",
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))
// Show performance message
                    Text(
                        message,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // BUTTON
            Button(
                onClick = {
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Back to Preview")
            }
        }
    }
}