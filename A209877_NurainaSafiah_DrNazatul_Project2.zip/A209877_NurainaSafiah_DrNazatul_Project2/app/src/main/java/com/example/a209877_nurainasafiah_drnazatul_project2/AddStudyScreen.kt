package com.example.a209877_nurainasafiah_drnazatul_project2

// Import required Jetpack Compose components
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

// Composable function for Add Study Task screen
@Composable
fun AddStudyScreen(
    navController: NavController,
    viewModel: MainViewModel
) {

    // Temporary UI states for user input fields
    var subject by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var hours by remember { mutableStateOf("") }

    // Main screen container with background color
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {

        // Vertical layout arrangement
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Screen title
            Text(
                text = "Add Study Task",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(Modifier.height(20.dp))

            // Input field for subject name
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it },
                label = { Text("Subject") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            // Input field for study topic
            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                label = { Text("Topic") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            // Input field for study hours
            OutlinedTextField(
                value = hours,
                onValueChange = { hours = it },
                label = { Text("Hours") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))

            // Button to save study task
            Button(
                onClick = {
                    // Input validation to prevent empty fields
                    if (subject.isNotBlank() &&
                        topic.isNotBlank() &&
                        hours.isNotBlank()
                    ) {
                        // FIX: Safely parse the String input into an Int for Room mapping
                        val parsedHours = hours.toIntOrNull() ?: 0

                        // Explicitly matching argument types
                        val task = StudyTask(
                            id = 0, // 0 tells Room to auto-generate the next unique ID number
                            subject = subject,
                            topic = topic,
                            hours = hours // Now perfectly passes an Int!
                        )

                        // Add task into ViewModel database task list
                        viewModel.addStudyTask(task)

                        // Navigate to Study List screen
                        navController.navigate("studyList")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Task")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Back button to return previous screen
            OutlinedButton(
                onClick = {
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Back")
            }
        }
    }
}