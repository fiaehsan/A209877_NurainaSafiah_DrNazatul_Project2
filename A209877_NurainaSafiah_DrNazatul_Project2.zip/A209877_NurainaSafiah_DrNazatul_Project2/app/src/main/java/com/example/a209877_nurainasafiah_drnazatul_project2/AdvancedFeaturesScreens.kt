package com.example.a209877_nurainasafiah_drnazatul_project2

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

// SCREEN 6: Retrofit API Quotes Screen
@Composable
fun QuoteScreen(navController: NavController, viewModel: MainViewModel) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SDG 4 Inspiration Hub", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(30.dp))

            if (viewModel.isApiLoading.value) {
                CircularProgressIndicator()
            } else {
                Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Text(text = "\"${viewModel.apiQuote.value}\"", fontSize = 18.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(12.dp))
                        Text(text = viewModel.apiAuthor.value, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.End))
                    }
                }
            }

            Spacer(Modifier.height(30.dp))
            Button(onClick = { viewModel.fetchEducationalQuote() }, modifier = Modifier.fillMaxWidth()) {
                Text("Fetch Live Quote (Retrofit)")
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { navController.popBackStack() }, modifier = Modifier.fillMaxWidth()) {
                Text("Back to Workspace")
            }
        }
    }
}

// SCREEN 7: Hardware Sensor Eye-Care Evaluator Screen
@Composable
fun SensorScreen(navController: NavController, viewModel: MainViewModel) {
    val context = LocalContext.current

    // Lifecycle setup to observe hardware light sensor safely
    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event != null) {
                    viewModel.lightIntensity.value = event.values[0]
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager.registerListener(listener, lightSensor, SensorManager.SENSOR_DELAY_UI)

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    val lux = viewModel.lightIntensity.value
    val statusMessage = when {
        lux < 150 -> "❌ Too Dim! Bad for long study sessions. Turn on a lamp to preserve eyesight."
        lux < 500 -> "🌱 Good! Acceptable conditions for standard study environments."
        else -> "🔥 Perfect! Optimal brightness for reading and high focus."
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Study Environment Health Evaluator", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(40.dp))

            Text("Current Ambient Light Level:", fontSize = 16.sp)
            Text("${lux.toInt()} LUX", fontSize = 48.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.secondary)

            Spacer(Modifier.height(24.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(text = statusMessage, modifier = Modifier.padding(20.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
            }

            Spacer(Modifier.height(40.dp))
            OutlinedButton(onClick = { navController.popBackStack() }, modifier = Modifier.fillMaxWidth()) {
                Text("Back to Dashboard")
            }
        }
    }
}