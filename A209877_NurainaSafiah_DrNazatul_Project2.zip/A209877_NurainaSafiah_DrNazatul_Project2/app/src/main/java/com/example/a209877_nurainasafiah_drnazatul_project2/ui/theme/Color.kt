package com.example.a209877_nurainasafiah_drnazatul_project2.ui.theme

import androidx.compose.ui.graphics.Color

// =====================
// 🌞 LIGHT COLORS
// =====================

val md_theme_light_primary = Color(0xFF1B8F5A)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFA8F0C8)
val md_theme_light_onPrimaryContainer = Color(0xFF002113)

val md_theme_light_secondary = Color(0xFF2AA9C5)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFBDE9F2)
val md_theme_light_onSecondaryContainer = Color(0xFF002B33)

// 🌿 CHANGED: Purple → Green (Tertiary)
val md_theme_light_tertiary = Color(0xFF1B8F5A)
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFA8F0C8)
val md_theme_light_onTertiaryContainer = Color(0xFF002113)

val md_theme_light_background = Color(0xFFF6FAF7)
val md_theme_light_onBackground = Color(0xFF1A1C1B)

val md_theme_light_surface = Color(0xFFFFFFFF)
val md_theme_light_onSurface = Color(0xFF1A1C1B)

val md_theme_light_surfaceVariant = Color(0xFFE0E3E0)
val md_theme_light_onSurfaceVariant = Color(0xFF424943)

val md_theme_light_outline = Color(0xFF727970)


// =====================
// 🌙 DARK COLORS
// =====================

val md_theme_dark_primary = Color(0xFF5FE2A0)
val md_theme_dark_onPrimary = Color(0xFF003822)
val md_theme_dark_primaryContainer = Color(0xFF005235)
val md_theme_dark_onPrimaryContainer = Color(0xFFA8F0C8)

val md_theme_dark_secondary = Color(0xFF6ED3EA)
val md_theme_dark_onSecondary = Color(0xFF00363F)
val md_theme_dark_secondaryContainer = Color(0xFF004E5A)
val md_theme_dark_onSecondaryContainer = Color(0xFFBDE9F2)

// 🌿 CHANGED: Purple → Green (Tertiary Dark)
val md_theme_dark_tertiary = Color(0xFF5FE2A0)
val md_theme_dark_onTertiary = Color(0xFF003822)
val md_theme_dark_tertiaryContainer = Color(0xFF005235)
val md_theme_dark_onTertiaryContainer = Color(0xFFA8F0C8)

val md_theme_dark_background = Color(0xFF0F1412)
val md_theme_dark_onBackground = Color(0xFFE1E3E0)

val md_theme_dark_surface = Color(0xFF121A17)
val md_theme_dark_onSurface = Color(0xFFE1E3E0)

val md_theme_dark_surfaceVariant = Color(0xFF424943)
val md_theme_dark_onSurfaceVariant = Color(0xFFC0C9C1)

val md_theme_dark_outline = Color(0xFF8A938C)