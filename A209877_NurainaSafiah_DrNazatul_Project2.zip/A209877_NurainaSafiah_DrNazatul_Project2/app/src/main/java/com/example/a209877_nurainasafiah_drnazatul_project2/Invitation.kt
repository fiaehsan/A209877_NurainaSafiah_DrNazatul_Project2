package com.example.a209877_nurainasafiah_drnazatul_project2
// Data class used to store user information
data class Invitation(
    val name: String = "",// Store user's name
    val xp: Int = 85, // Store user's XP points
    val streak: Int = 7 // Store user's study streak
)