package com.example.a209877_nurainasafiah_drnazatul_project2.ui.theme

import androidx.compose.material3.Typography

// Default Material 3 Typography
val Typography = Typography()