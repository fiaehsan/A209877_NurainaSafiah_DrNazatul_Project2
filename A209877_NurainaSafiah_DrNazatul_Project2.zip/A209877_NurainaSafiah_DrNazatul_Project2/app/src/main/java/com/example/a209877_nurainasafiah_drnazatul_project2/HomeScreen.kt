package com.example.a209877_nurainasafiah_drnazatul_project2

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: MainViewModel
) {
    // Get shared user data from ViewModel
    val data = viewModel.invitation.value

    // Task completion states
    var task1 by remember { mutableStateOf(true) }
    var task2 by remember { mutableStateOf(true) }
    var task3 by remember { mutableStateOf(false) }

    // Timer states
    var timer by remember { mutableStateOf(1500) }
    var isRunning by remember { mutableStateOf(false) }

    // State for expanding/collapsing task section
    var expandedTasks by remember { mutableStateOf(false) }

    // Coroutine effect for countdown timer
    LaunchedEffect(isRunning) {
        if (isRunning) {
            // Decrease timer every second
            while (timer > 0) {
                delay(1000)
                timer--
            }
        }
    }

    // Animate progress bar smoothly
    val progress by animateFloatAsState(
        targetValue = data.xp / 400f,
        animationSpec = tween(800)
    )

    // Main vertical layout configuration
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            // FIX: Allows the user to swipe/scroll vertically down the screen layout
            .verticalScroll(rememberScrollState())
    ) {

        // HEADER SECTION
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(20.dp))
        ) {
            if (!LocalInspectionMode.current) {
                Image(
                    painter = painterResource(id = R.drawable.jungle),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
            )

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text("EduMate", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Stay consistent 🌱", fontSize = 14.sp)
                }

                Text("🔥 ${data.streak}", fontSize = 18.sp)
            }
        }

        Spacer(Modifier.height(20.dp))

        // USER DETAILS PROFILE CARD
        Card(
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Welcome 👋")
                Spacer(Modifier.height(8.dp))
                TextField(
                    value = data.name,
                    onValueChange = { viewModel.updateName(it) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Enter your name") }
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.addXP() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Submit")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // POMODORO TIMER CARD
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Focus Timer")
                Text(
                    String.format("%02d:%02d", timer / 60, timer % 60),
                    fontSize = 28.sp
                )
                Button(onClick = { isRunning = !isRunning }) {
                    Text(if (isRunning) "Pause" else "Start")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // XP PROGRESS TRACKER CARD
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Your Progress")
                Text("XP: ${data.xp} / 400")
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ANIMATED TODAY'S TASKS CARD
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expandedTasks = !expandedTasks }
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Today's Tasks")
                AnimatedVisibility(expandedTasks) {
                    Column {
                        Text(
                            if (task1) "✔ Queue Module" else "⬜ Queue Module",
                            modifier = Modifier.clickable { task1 = !task1 }
                        )
                        Text(
                            if (task2) "✔ Revise Notes" else "⬜ Revise Notes",
                            modifier = Modifier.clickable { task2 = !task2 }
                        )
                        Text(
                            if (task3) "✔ Practice Coding" else "⬜ Practice Coding",
                            modifier = Modifier.clickable { task3 = !task3 }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SUBMISSION TARGET CHANNEL BUTTONS
        Button(
            onClick = { navController.navigate("quoteHub") },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
        ) {
            Text("Open Quote Hub (Retrofit API)")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { navController.navigate("lightSensor") },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
        ) {
            Text("Test Workspace Environment (Light Sensor)")
        }

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = { navController.navigate("preview") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Go to Preview")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { navController.navigate("addStudy") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add Study Task")
        }

        Spacer(modifier = Modifier.height(10.dp))

        // CORE DESTINATION TARGET: VIEW STUDY LIST BUTTON
        OutlinedButton(
            onClick = { navController.navigate("studyList") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("View Study List")
        }
    }
}