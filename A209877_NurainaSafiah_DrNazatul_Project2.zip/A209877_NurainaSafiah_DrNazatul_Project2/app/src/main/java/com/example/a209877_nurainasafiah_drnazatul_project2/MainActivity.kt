package com.example.a209877_nurainasafiah_drnazatul_project2

// Import Android and Jetpack Compose components
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.a209877_nurainasafiah_drnazatul_project2.ui.theme.project1Theme

class MainActivity : ComponentActivity() { // Main entry point of the application

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set Jetpack Compose UI content
        setContent {
            project1Theme {

                // Navigation controller for screen navigation
                val navController = rememberNavController()

                // Instantiates MainViewModel with the proper context factory context parameter matching AndroidViewModel(application)
                val viewModel: MainViewModel = viewModel(
                    factory = object : ViewModelProvider.Factory {
                        @Suppress("UNCHECKED_CAST")
                        override fun <T : ViewModel> create(modelClass: Class<T>): T {
                            return MainViewModel(application) as T
                        }
                    }
                )

                AppNavGraph(navController, viewModel)
            }
        }
    }
}

@Composable
fun AppNavGraph(
    navController: NavHostController,
    viewModel: MainViewModel
) {
    NavHost(navController = navController, startDestination = "home") {
        composable("home") { HomeScreen(navController, viewModel) }
        composable("preview") { PreviewScreen(navController, viewModel) }
        composable("details") { DetailsScreen(navController, viewModel) }
        composable("addStudy") { AddStudyScreen(navController, viewModel) }
        composable("studyList") { StudyListScreen(navController, viewModel) }

        // Core target channels for your submission requirements
        composable("quoteHub") { QuoteScreen(navController, viewModel) }
        composable("lightSensor") { SensorScreen(navController, viewModel) }
    }
}