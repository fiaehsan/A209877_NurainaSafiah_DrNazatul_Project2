package com.example.a209877_nurainasafiah_drnazatul_project2

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue // Allows the 'by' delegate syntax to work cleanly
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun StudyListScreen(navController: NavController, viewModel: MainViewModel) {
    // Collect task updates from Room Database Flow channel live
    // Double-check your MainViewModel property variable matches this exact name!
    val tasks by viewModel.roomStudyTasks.collectAsState(initial = emptyList())

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Screen Header Title
            Text(
                text = "Study Task List (Room Powered)",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(Modifier.height(20.dp))

            // Fallback text if the local database list is empty
            if (tasks.isEmpty()) {
                Text(
                    text = "No saved database entries located yet.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            // Scrollable List container
            LazyColumn(
                modifier = Modifier.weight(1f) // Allows list to scroll independently while keeping buttons visible
            ) {
                items(tasks) { task ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(text = "📚 Subject: ${task.subject}", style = MaterialTheme.typography.bodyLarge)
                            Text(text = "📝 Topic: ${task.topic}", style = MaterialTheme.typography.bodyMedium)
                            Text(text = "⏰ Hours: ${task.hours}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Bottom Back Navigation button
            OutlinedButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Back")
            }
        }
    }
}